=== WooCommerce Hutkigrosh Gateway ===
Contributors: nmekh
Tags: commerce, woocommerce, hutkigrosh, shopping, gateway, erip
Stable tag: trunk
Requires at least: 4.6
Tested up to: 4.9
Requires PHP: 5.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Woocommerce ERIP (Belarus) integration via Hutkigrosh Gateway

== Description ==
Hutkigrosh™ — payment service for invoicing in AIS *Raschet* (ERIP) Belarus.
After invoicing you clients will be available for payment by a plastic card and electronic money, at any of the bank branches, cash desks, ATMs, payment terminals, in the electronic money system, through Internet banking, M-banking, Internet acquiring.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Woocommerce->Settings->Payments screen to configure the plugin

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot
